#ifndef COLOR_H
#define COLOR_H
#include <stdint.h>

struct Color {
  uint8_t r, g, b;
};

#endif // COLOR_H
